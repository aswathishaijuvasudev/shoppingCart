import React from 'react'
import download from '../assets/download.png'
export const NotFound = () => {
  return (
    <div className='main'>
        <img src={download}></img>
    </div>
  )
}
